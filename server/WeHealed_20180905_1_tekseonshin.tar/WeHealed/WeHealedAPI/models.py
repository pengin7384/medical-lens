# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.utils.safestring import mark_safe

from django.db import models

# Create your models here.
class Dictionary(models.Model):
    abbreviation_text = models.CharField(max_length=200)
    original_text = models.CharField(max_length=500)
    organization_text = models.CharField(max_length=200)
    detail_text = models.CharField(max_length=5000)
    
    def __str__(self):
        return self.abbreviation_text

class Pedia(models.Model):
    name = models.CharField(max_length=200)
    url = models.CharField(max_length=1000)
    score = models.IntegerField(default=10)
    reply_total = models.IntegerField(default=0)
    reply_yes = models.IntegerField(default=0)
    reply_no = models.IntegerField(default=0)

    def __str__(self):
        return self.name 
                             
                             
class DataSet(models.Model):
    origin_sentence     = models.CharField(max_length=2000)
    translated_sentence = models.CharField(max_length=2000)
    
    def __str__(self):
        return self.origin_sentence
    
    
class RuleDataSet(models.Model):
    origin_sentence         = models.CharField(max_length=2000)
    translated_sentence     = models.CharField(max_length=2000)
    size                    = models.IntegerField(default=0)
    def __str__(self):
        return self.origin_sentence
    

class MedicalRecordImageDB(models.Model):
    filename = models.CharField(max_length=200)
    image = models.ImageField(upload_to="MedicalRecordImages/")

    def image_tag(self):
        if self.image:
            return mark_safe('<img src="%s" style="width: 45px; height:45px;" />' % self.image.url)
        else:
            return 'No Image Found'

    image_tag.short_description = 'Image'

    def __str__(self):
        return self.filename

    