# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import JsonResponse
from WeHealedAPI.models import Dictionary, Pedia, DataSet, RuleDataSet, MedicalRecordImageDB
from WeHealedAPI.serializers import WeHealedAPISerializer
from django.views.decorators.csrf import csrf_exempt

# Google Cloud Language API
from google.cloud import language
from google.cloud.language import enums
from google.cloud.language import types

# google Translation API
import argparse
from google.cloud import translate
import six

import random
import os
import codecs

# rule
import re

# Create your views here.
def substitution(request):
    dic = Dictionary.objects
    sentence = request.GET.get('sentence', '')
    token_sentence = sentence.split(' ')
    
    if len(sentence) == 0:
        status = 'Error'
        result = 'Input Sentence'
    else:
        status = 'Success'
        result = ''
        for tok in token_sentence:
            try:
                # word = dic.get(abbreviation_text=tok)
                # words = list(dic.filter(abbreviation_text=tok))
                words = dic.filter(abbreviation_text=tok)
                # word = words.filter(organization_text="heart")
                # print(word.values("original_text"))
                # print(len(words))
                if(len(words)==0):
                    result += tok + ' '
                else:
                    for w in words:
                        result += w.original_text
                        break
                # result += word.original_text + ' '
            except Dictionary.DoesNotExist:
                result += tok + ' '

    return JsonResponse({'status': status, 'result': result})    

# test
def test(request):
    text = request.GET.get('text', '')
    #return JsonResponse({'req_data': text})
    
    return JsonResponse({'text': text})


# Google Cloud Language API
# gcloud init 
# https://cloud.google.com/natural-language/docs/basics#syntactic_analysis_requests
def token(request):
    text = request.GET.get('text', '')
    # Instantiates a clie
    client = language.LanguageServiceClient()

    if isinstance(text, six.binary_type):
        text = text.decode('utf-8')

    # Instantiates a plain text document.
    document = types.Document(
        content=text,
        type=enums.Document.Type.PLAIN_TEXT)

    # Detects syntax in the document. You can also analyze HTML with:
    #   document.type == enums.Document.Type.HTML
    tokens = client.analyze_syntax(document).tokens

    # part-of-speech tags from enums.PartOfSpeech.Tag
    pos_tag = ('UNKNOWN', 'ADJ', 'ADP', 'ADV', 'CONJ', 'DET', 'NOUN', 'NUM',
               'PRON', 'PRT', 'PUNCT', 'VERB', 'X', 'AFFIX')

    for token in tokens:
        print(u'{}: {}'.format(pos_tag[token.part_of_speech.tag],
                               token.text.content))
    
    return JsonResponse({'text': text})



# google translate api
# gcloud init -> 로그인 필요할 수 있음
# export 명령은 실행 명령에 추가했습니다.
def trans(request):
    status = 'init'

    """ substitution """
    dic = Dictionary.objects
    sentence = request.GET.get('sentence', '')
    token_sentence = sentence.split(' ')
    
    if len(sentence) == 0:
        status = 'Error'
        result = 'Input Sentence'
    else:
        status = 'Success'
        result = ''
        for tok in token_sentence:
            try:
                # word = dic.get(abbreviation_text=tok)
                # words = list(dic.filter(abbreviation_text=tok))
                words = dic.filter(abbreviation_text=tok)
                # word = words.filter(organization_text="heart")
                # print(word.values("original_text"))
                # print(len(words))
                if(len(words)==0):
                    result += tok + ' '
                else:
                    for w in words:
                        result += w.original_text
                        break
                # result += word.original_text + ' '
            except Dictionary.DoesNotExist:
                result += tok + ' '
                
    print ('Substitution result : ' + result)            
    sentence = result
    
    """ translate """
    # input = request.GET.get('sentence', '')
    target = 'ko'
    translate_client = translate.Client()

    if isinstance(sentence, six.binary_type):
        sentence = sentence.decode('utf-8')

    # Text can also be a sequence of strings, in which case this method   # will return a sequence of results for each text.
    result = translate_client.translate(sentence, target_language=target)

    print(u'Text: {}'.format(result['input']))
    print(u'Translation: {}'.format(result['translatedText']))
    print(u'Detected source language: {}'.format(result['detectedSourceLanguage']))

    return JsonResponse({'status': status, 'result': result})

def getNumeric(request):
    
    import re
    unitL = sorted(['mm', 'mm2', 'mm3', 'cm', 'cm2', 'cm3', 'mmHg'], key=lambda x:len(x), reverse=True)
    
    valueD = dict()
    sentence = request.GET.get('sentence', '')
    searched = re.search(r'\((.*?)\)',sentence)
    
    if searched == None:
        status = "Error"
        return JsonResponse({'status': status, 'sentence': sentence, 'result': valueD})

    subsentenceL = searched.group(1).split(',')
    
    for subsentence in subsentenceL:
        # Split by delimiter = or :
        pair = [x.strip() for x in re.split('= |:', subsentence)]
        if len(pair) != 2:
            continue
                
        # Split by delimiter UNIT (mm, cm, ...)
        key, value_raw = pair
        valueL = re.split('(%s)' % '|'.join(unitL), value_raw)
        value = valueL[0]
        unit  = valueL[1]
        info = valueL[2] if len(valueL) > 2 else 'none'

        valueD[key] = {
            'value': value, 
            'unit': unit,
            'info': info,
            'extended_help': 'http://www.FAKEURL.com/'
        }
    if len(valueD) > 0:
        status = 'Success'
    else:
        status = 'ERROR'
    return JsonResponse({'status': status, 'sentence': sentence, 'result': valueD})

def url_recommend(requests):
    total = 0
    idx_list = []
    idx = 0
    query = requests.GET.get('query','')    
    pedia = Pedia.objects.all()
    for p in pedia:
        total += p.score
        idx_list.append(total)
    
    randnum = random.randint(1, total)
    
    for i in idx_list:
        if randnum <= i:
            break
        idx += 1
    
    return JsonResponse({'name': pedia[idx].name, 'url': pedia[idx].url + query})


def update_recommend(requests):
    status = ''
    name = requests.GET.get('name','')
    point = requests.GET.get('point','')
    
    if len(name) == 0 or len(point) == 0:
        status = "Failed"
    else:
        try:
            pedia = Pedia.objects.get(name=name)
            point = int(point)
            status = "Success"
            pedia.score += point
            if pedia.score < 1:
                pedia.score = 1
            pedia.save()
        except Pedia.DoesNotExist:
            status = "Failed2"
            pass
    
    return JsonResponse({'status': status})

def make_dataset(requests):
    status = 'init'
    path = os.getcwd()
    dataset = DataSet.objects.all().delete()
    
    infile = codecs.open(path + '/WeHealedAPI/SentenceData/infile.txt', 'r', encoding='UTF8')
    outfile = codecs.open(path + '/WeHealedAPI/SentenceData/outfile.txt', 'w', encoding='UTF8')

    while True:
        line = infile.readline()
        if not line: break

        """ translate """
        target = 'ko'
        translate_client = translate.Client()

        if isinstance(line, six.binary_type):
            line = line.decode('UTF8')

        line = line.strip()
        if len(line) == 0: continue
            
        result = translate_client.translate(line, target_language=target)
        result_line = result['translatedText']
        print(u'***\nText: {}'.format(result['input']))
        print('@@@')
        print(u'Translation: {}'.format(result_line))

        result_line = result_line.encode('UTF8')
        # outfile.write(result_line)
        # outfile.write('\n')

        # DB에 넣어야 함 왜 안들어감 ㅠㅠ
        # dataset = DataSet.objects.create(origin_sentence=line, translated_sentence=result_line)
        dataset = DataSet(origin_sentence=line, translated_sentence=result_line)
        dataset.save(force_insert=True)
        
    infile.close()
    outfile.close()
    return JsonResponse({'status': status})


# rule test

'''
def rule(request):
    #text = request.GET.get('text', '')
    pattern = r'Lymph node. "(?P<num>.+)"'
    text = request.GET.get('text', '')

    r = re.compile(pattern, re.IGNORECASE)
    m = r.search(text)
    if(m):
        newText = r.sub('"' + m.group("num") + '번 림프절"', text)
    else:
        newText = text
    print(newText)
 
    return JsonResponse({'text': newText})
'''


# Choi sang hee
def rule(request):
    text = request.GET.get('text', '')
    words = text.split(' ')
    
    
    
    for n in range(3, 2, -1): # ngram( 3n - 2n - 1n ) 
        print(n)
        for i in range(0, len(words)-n+1):
            str = ""
            for j in range(0, n):
                str = str + words[i+j] + " "
            str = str[:-1]
            #print( "("+str+")")
    
            try:
                str2 = RuleDataSet.objects.get(origin_sentence=str)
            except RuleDataSet.DoesNotExist:
                str2 = None
            if(str2 != None):
                #print(str2.translated_sentence)
                text = re.sub(str, str2.translated_sentence, text)
                
    return JsonResponse({'text': text})



# Add rule
# Choi sang hee
def add_rule(request):
    before = request.GET.get('before', '')
    after = request.GET.get('after', '')
    
    words = before.split(' ')
    
    #print(len(words))
    
    rds = RuleDataSet(origin_sentence=before, translated_sentence=after, size=len(words))
    rds.save()
    
    
    return JsonResponse({'before': before, 'after': after})


# CSRF Cookie Not Set 오류 발생를 임시로 off
# 의무기록 이미지 업로드 API
@csrf_exempt
def image_upload(request):
    if request.method == 'POST':
        try:
            MRI = MedicalRecordImageDB(filename=request.POST['filename'], image=request.FILES['image'])
            MRI.save()
            return JsonResponse({"status": "Success"})
        except KeyError:
            return JsonResponse({"status": "Failed"})
    return JsonResponse({"status": "Failed"})

