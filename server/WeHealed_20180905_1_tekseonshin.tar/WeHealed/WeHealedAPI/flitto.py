# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import JsonResponse
from WeHealedAPI.models import Dictionary, Pedia, DataSet, RuleDataSet
from WeHealedAPI.serializers import WeHealedAPISerializer

# Google Cloud Language API
from google.cloud import language
from google.cloud.language import enums
from google.cloud.language import types

# google Translation API
import argparse
from google.cloud import translate
import six

import random
import os
import codecs

# rule
import re

import json

# 일단 CSRF를 끄고 구현
from django.views.decorators.csrf import csrf_exempt
@csrf_exempt
def receive_result(request):
    
    if request.method == 'POST' :

        request_data = ((request.body).decode('utf-8'))
        request_data = json.loads(request_data)
        src_lang_code = request_data['src_lang_code']
        dst_lang_code = request_data['dst_lang_code']
        cp_transaction_id = request_data['cp_transaction_id']
        content = request_data['content']
        callback_url = request_data['callback_url']
        
        # TODO : DB 에 저장
        # key : cp_transaction_id
        # 추가 저장 할 것 : 답변이 들어온 시간. 
        
        return JsonResponse({
            'src_lang_code': src_lang_code,
            'dst_lang_code': dst_lang_code,
            'cp_transaction_id': cp_transaction_id,
            'content': content,
            'callback_url': callback_url,
            'result': 'success'
        })
    
    else :
        return JsonResponse({'result': 'fail', 'reason': 'Try POST Method please'})
	
	
	
